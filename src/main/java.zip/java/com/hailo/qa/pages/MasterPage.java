package com.hailo.qa.pages;

import com.hailo.qa.base.TestBase;

public class MasterPage extends TestBase {

}
