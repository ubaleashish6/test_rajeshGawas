package com.hailo.qa.pages;

import com.hailo.qa.base.TestBase;

public class CulinaryPage extends TestBase {

}
